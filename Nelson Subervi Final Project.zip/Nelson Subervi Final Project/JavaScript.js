var users = []; //Esto va a ser lo que divida quie
var totalBill= 0;
//Funcion que creat los objetos en mi array

			function bill(){
				var names= document.getElementById('Name').value.split(',')
				tootalBill= document.getElementById("bill").value
				var avg = totalBill/names.length;
				for (var i = 0; i< names.length ; i++) {
					var Person = { name: names[i], average:avg }
					users.push(Person);
				}
			}

			function Separacion(){
				 for (var i = 0; i <billSplit.name.length; i++){
					billSplit[i].percentage/ billSplit.percentage.length};
				promedio = bill/ bill.length;
			}

// Necesito saber como comvertir numeros enteros a porcentaje
//Funcion que divide el costo equitativamente entre cada usuario
//Se divide la factura equitativamente. 
//Cada Objeto de recibe un porcentaje equitativo del la factura
// No se como agregar todos los datos en la factura.
// Podria anadir todo en la suma de cada uno de los objetos.
// No se como arreglar mi codigo y hacerlo mas eficiente
			function saveData(){
				percentage: document.getElementById('porcentaje').value,
				percentage = (percentage)*100;
				billSplit.push(percentage());
				prompt()
			}


// Funcion que retorna los resultados al citio web.
			function displayCookBook(){
				document.getElementById('display').innerHTML = '';
				
				for(var i=0; i<bill.length; i++){
					document.getElementById('display').innerHTML += '<li>' + bill[i].name + ' includes ' +
					billSplit[i].ingredients.join(' and ') + '. It takes '+
					billSplit[i].percentage + ' to cook</li>';
				}
			}
			/*
var count = 0;
			document.getElementById('increase').addEventListener('click', function(){
				count++; //increases count by 1
				document.getElementById('display').innerHTML = count;
			});
			for( var i = 0 ; i < list.length; i++){
    if (list[i].gender=='female'){
      female ++
      suma += list[i].age;
			*/